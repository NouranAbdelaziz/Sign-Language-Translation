#!/usr/bin/env python
from onmt.bin.average_models import main


if __name__ == "__main__":
    main()
