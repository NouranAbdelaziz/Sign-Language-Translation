The phoenix14T data is from [O. Koller, J. Forster, and H. Ney. Continuous sign language recognition: Towards large vocabulary statistical recognition systems handling multiple signers. Computer Vision and Image Understanding, volume 141, pages 108-125, December 2015.](https://www.researchgate.net/publication/284070363_Continuous_sign_language_recognition_Towards_large_vocabulary_statistical_recognition_systems_handling_multiple_signers)

The stmc gloss data is from [H. Zhou, W. Zhou, Y. Zhou, and H. Li.  Spatial-Temporal Multi-Cue Network for Continuous SignLanguage  Recognition, AAAI2020, 2020"](https://arxiv.org/abs/2002.03187).
It is shared by Hao Zhou from the GIPAS lab in USTC, for non-commercial usage.


The aslg data is from [Achraf Othman and Zouhour Tmar. “English-ASL Gloss Parallel Corpus 2012: ASLG-PC12, The Second Release”. Fourth International Conference On Information and Communication Technology and Accessibility ICTA’13, Hammamet, Tunisia, October 24-26, 2013.](https://pdfs.semanticscholar.org/473f/ffb95c3db24938a21346ecd117a8a9204404.pdf)
