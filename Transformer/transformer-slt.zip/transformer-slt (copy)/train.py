#!/usr/bin/env python
from onmt.bin.train import main


if __name__ == "__main__":
    main()
