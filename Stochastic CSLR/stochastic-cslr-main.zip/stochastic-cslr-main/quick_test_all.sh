python3 quick_test.py --model sfl --use-lm --split dev
python3 quick_test.py --model sfl --use-lm --split test
python3 quick_test.py --model dfl --use-lm --split dev
python3 quick_test.py --model dfl --use-lm --split test
python3 quick_test.py --model sfl --split dev
python3 quick_test.py --model sfl --split test
python3 quick_test.py --model dfl --split dev
python3 quick_test.py --model dfl --split test
